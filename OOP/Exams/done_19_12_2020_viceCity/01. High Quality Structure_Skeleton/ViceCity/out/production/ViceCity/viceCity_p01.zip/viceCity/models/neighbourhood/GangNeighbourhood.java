package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.Player;
import viceCity.repositories.interfaces.Repository;

import java.util.Collection;

public class GangNeighbourhood implements Neighbourhood{
    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {
        while (!isAllDead(civilPlayers) && isRunOutGuns(mainPlayer.getGunRepository()) ){

        }

    }

    private boolean isRunOutGuns(Repository<Gun> gunRepository) {
        return false;
    }

    private boolean isAllDead(Collection<Player> civilPlayers) {
        for (Player civilPlayer : civilPlayers) {
            if (civilPlayer.isAlive()){
                return false;
            }
        }
        return true;
    }


}
