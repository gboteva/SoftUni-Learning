import implementations.DoublyLinkedList;
import implementations.Queue;

public class Main {
    public static void main(String[] args) {

        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.addLast(14);
        list.addLast(68);
        list.addLast(80);
        list.removeLast();

    }
}
