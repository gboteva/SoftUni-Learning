import implementations.ArrayDeque;
import implementations.DoublyLinkedList;
import implementations.Queue;

public class Main {
    public static void main(String[] args) {

        ArrayDeque<Integer> deque = new ArrayDeque<>();
        deque.add(10);
        deque.offer(11);
        deque.addLast(12);
        deque.addFirst(9);
        System.out.println("----------------------------");

        deque.remove(0);
        deque.removeFirst();
        deque.removeLast();
        deque.remove(Integer.valueOf(11));

    }
}
