import implementations.ArrayDeque;
import implementations.DoublyLinkedList;
import implementations.Queue;
import implementations.ReversedList;

public class Main {
    public static void main(String[] args) {

        ReversedList<Integer> list = new ReversedList<>();
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(6);
        list.add(7);
        list.add(8);

        list.removeAt(0);
        int element = list.get(0);
        //System.out.println(element);

        for (Integer num : list) {
            System.out.print(num + " ");
        }
    }
}
